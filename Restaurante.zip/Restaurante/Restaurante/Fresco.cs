﻿using Restaurante.Restaurante;
using System;

namespace Restaurante
{
    class Fresco : Producto
    {
        public Fresco(string nombre, decimal precio) : base(nombre, precio) { }
    }
}