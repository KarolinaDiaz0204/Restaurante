﻿using Restaurante.Restaurante;
using System;

namespace Restaurante
{
    class Bebida : Producto
    {
        public Bebida(string nombre, decimal precio) : base(nombre, precio) { }
    }
}
