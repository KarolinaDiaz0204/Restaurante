﻿using Restaurante.Restaurante;
using System;

namespace Restaurante
{
    public class Quesillo : Producto
    {
        public Quesillo(string nombre, decimal precio) : base(nombre, precio) { }
    }
}
   